package com.nettrack.app

import kotlinx.coroutines.*
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.min

/** Real measurements against Cloudflare's public speed-test endpoints (HTTPS). */
object SpeedEngine {
    private const val DOWN = "https://speed.cloudflare.com/__down?bytes="
    private const val UP = "https://speed.cloudflare.com/__up"
    private const val TEST_NANOS = 8_000_000_000L

    /** Returns (average HTTP round-trip ms, jitter ms). First sample (TLS setup) is discarded. */
    suspend fun ping(): Pair<Double, Double> = withContext(Dispatchers.IO) {
        val t = mutableListOf<Double>()
        repeat(7) {
            val t0 = System.nanoTime()
            val c = URL(DOWN + "0").openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.inputStream.use { it.readBytes() }
            t += (System.nanoTime() - t0) / 1e6
        }
        val s = t.drop(1)
        s.average() to s.zipWithNext { a, b -> abs(a - b) }.average()
    }

    suspend fun download(onSpeed: (Double) -> Unit): Double = coroutineScope {
        val total = AtomicLong(0)
        val errors = AtomicInteger(0)
        val start = System.nanoTime()
        val deadline = start + TEST_NANOS
        val workers = List(4) {
            async(Dispatchers.IO) {
                val buf = ByteArray(64 * 1024)
                while (System.nanoTime() < deadline && isActive) {
                    val c = URL(DOWN + "25000000").openConnection() as HttpURLConnection
                    try {
                        c.connectTimeout = 8000; c.readTimeout = 8000
                        c.inputStream.use { s ->
                            while (System.nanoTime() < deadline) {
                                val n = s.read(buf); if (n < 0) break
                                total.addAndGet(n.toLong())
                            }
                        }
                    } catch (e: IOException) {
                        // tolerate a failed connection as long as other workers deliver data
                        if (errors.incrementAndGet() >= 8 && total.get() == 0L) throw e
                        delay(200)
                    } finally { c.disconnect() }
                }
            }
        }
        val reporter = launch { report(total, start, onSpeed) }
        workers.awaitAll(); reporter.cancel()
        finish(total.get(), start)
    }

    suspend fun upload(onSpeed: (Double) -> Unit): Double = coroutineScope {
        val total = AtomicLong(0)
        val errors = AtomicInteger(0)
        val start = System.nanoTime()
        val deadline = start + TEST_NANOS
        val body = 250_000 // small requests so slow uplinks still make steady progress
        val workers = List(3) {
            async(Dispatchers.IO) {
                val chunk = ByteArray(16 * 1024)
                while (System.nanoTime() < deadline && isActive) {
                    val c = URL(UP).openConnection() as HttpURLConnection
                    try {
                        c.requestMethod = "POST"; c.doOutput = true
                        c.connectTimeout = 8000; c.readTimeout = 20000
                        c.setFixedLengthStreamingMode(body)
                        c.outputStream.use { o ->
                            var sent = 0
                            while (sent < body) {
                                val n = min(chunk.size, body - sent)
                                o.write(chunk, 0, n); sent += n; total.addAndGet(n.toLong())
                            }
                        }
                        c.responseCode
                    } catch (e: IOException) {
                        if (errors.incrementAndGet() >= 8 && total.get() == 0L) throw e
                        delay(200)
                    } finally { c.disconnect() }
                }
            }
        }
        val reporter = launch { report(total, start, onSpeed) }
        workers.awaitAll(); reporter.cancel()
        finish(total.get(), start)
    }

    private suspend fun report(total: AtomicLong, start: Long, onSpeed: (Double) -> Unit) {
        var lastB = 0L; var lastT = start
        while (true) {
            delay(300)
            val now = System.nanoTime(); val b = total.get()
            onSpeed((b - lastB) * 8.0 / ((now - lastT) / 1e9) / 1e6)
            lastB = b; lastT = now
        }
    }

    private fun finish(bytes: Long, start: Long): Double {
        if (bytes == 0L) throw IllegalStateException("no data received")
        return bytes * 8.0 / ((System.nanoTime() - start) / 1e9) / 1e6
    }
}

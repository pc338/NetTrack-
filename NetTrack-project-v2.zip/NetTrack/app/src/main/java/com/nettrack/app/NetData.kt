package com.nettrack.app

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class TestResult(
    val time: Long, val operator: String, val connection: String,
    val download: Double, val upload: Double, val pingMs: Double, val jitterMs: Double
)

data class NetInfo(val operator: String, val connection: String)

fun normalizeOperator(raw: String): String {
    val s = raw.lowercase().trim()
    return when {
        s.isBlank() -> "Unknown"
        "jio" in s -> "Jio"
        "airtel" in s -> "Airtel"
        "vodafone" in s || "idea" in s || s == "vi" || s.startsWith("vi ") || s.startsWith("vi-") -> "Vi"
        "bsnl" in s || "cellone" in s -> "BSNL"
        else -> raw.trim()
    }
}

fun readNetInfo(ctx: Context): NetInfo {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val tm = ctx.getSystemService(TelephonyManager::class.java)
    return when {
        caps == null -> NetInfo("--", "Offline")
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetInfo("Wi-Fi", "Wi-Fi")
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
            NetInfo(normalizeOperator(tm.networkOperatorName ?: ""), cellType(ctx, tm))
        else -> NetInfo("Other", "Other")
    }
}

private fun cellType(ctx: Context, tm: TelephonyManager): String = try {
    val ok = android.os.Build.VERSION.SDK_INT < 30 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
    if (!ok) "Mobile data" else when (tm.dataNetworkType) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G"
        TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
        TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS -> "2G"
        else -> "Mobile data"
    }
} catch (e: SecurityException) { "Mobile data" }

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("nettrack", Context.MODE_PRIVATE)

    fun load(c: Context): List<TestResult> {
        val a = JSONArray(prefs(c).getString("history", "[]"))
        return List(a.length()) { i ->
            a.getJSONObject(i).let {
                TestResult(it.getLong("t"), it.getString("op"), it.getString("conn"),
                    it.getDouble("d"), it.getDouble("u"), it.getDouble("p"), it.getDouble("j"))
            }
        }
    }

    private fun save(c: Context, l: List<TestResult>) {
        val a = JSONArray()
        l.forEach { r ->
            a.put(JSONObject().put("t", r.time).put("op", r.operator).put("conn", r.connection)
                .put("d", r.download).put("u", r.upload).put("p", r.pingMs).put("j", r.jitterMs))
        }
        prefs(c).edit().putString("history", a.toString()).apply()
    }

    fun add(c: Context, r: TestResult): List<TestResult> {
        val l = (listOf(r) + load(c)).take(200); save(c, l); return l
    }

    fun clear(c: Context) { save(c, emptyList()) }
}

class NetViewModel(app: Application) : AndroidViewModel(app) {
    var running by mutableStateOf(false)
    var phase by mutableStateOf("")
    var liveSpeed by mutableStateOf<Float?>(null)
    var ping by mutableStateOf<Double?>(null)
    var jitter by mutableStateOf<Double?>(null)
    var download by mutableStateOf<Double?>(null)
    var upload by mutableStateOf<Double?>(null)
    var error by mutableStateOf<String?>(null)
    var history by mutableStateOf(Store.load(app))
    var net by mutableStateOf(readNetInfo(app))

    fun refreshNet() { net = readNetInfo(getApplication()) }

    fun clearHistory() { Store.clear(getApplication()); history = emptyList() }

    fun start() {
        if (running) return
        viewModelScope.launch {
            running = true; error = null
            ping = null; jitter = null; download = null; upload = null; liveSpeed = null
            refreshNet()
            if (net.connection == "Offline") { error = "No internet connection"; running = false; return@launch }
            try {
                phase = "Measuring ping…"
                val (p, j) = SpeedEngine.ping(); ping = p; jitter = j
                phase = "Testing download…"
                download = SpeedEngine.download { liveSpeed = it.toFloat() }
                liveSpeed = download?.toFloat()
                phase = "Testing upload…"
                upload = SpeedEngine.upload { liveSpeed = it.toFloat() }
                liveSpeed = upload?.toFloat()
                history = Store.add(getApplication(),
                    TestResult(System.currentTimeMillis(), net.operator, net.connection,
                        download!!, upload!!, p, j))
                phase = "Done"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Test failed: ${e.message ?: "network error"}"; phase = ""
            } finally { running = false }
        }
    }
}

package com.nettrack.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Speedometer. value == null means "no measurement" and shows "--" (never a fake number). */
@Composable
fun Speedometer(value: Float?, max: Float = 100f, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val prim = MaterialTheme.colorScheme.primary
    val sweep = 240f * ((value ?: 0f) / max).coerceIn(0f, 1f)
    Box(modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val inset = 24f
            val sz = Size(size.width - 2 * inset, size.height - 2 * inset)
            val st = Stroke(width = 24f, cap = StrokeCap.Round)
            drawArc(track, 150f, 240f, false, Offset(inset, inset), sz, style = st)
            if (sweep > 0f) drawArc(prim, 150f, sweep, false, Offset(inset, inset), sz, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value?.let { "%.1f".format(it) } ?: "--", fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Text("Mbps", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun SourceChip(label: String, color: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 11.sp)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}

fun meterMax(v: Float?) = when { v == null || v <= 100f -> 100f; v <= 300f -> 300f; else -> 1000f }
fun fmtTime(t: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))
fun f1(v: Double?) = v?.let { "%.1f".format(it) } ?: "--"

@Composable
fun HomeScreen(vm: NetViewModel, onRunTest: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshNet() }
    LaunchedEffect(Unit) {
        vm.refreshNet()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.READ_PHONE_STATE)
    }
    val last = vm.history.firstOrNull()
    Page {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Current network (read from device)", fontSize = 12.sp)
                Text("${vm.net.operator}  •  ${vm.net.connection}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Speedometer(last?.download?.toFloat(), meterMax(last?.download?.toFloat()))
                if (last != null) SourceChip("Historical: last test ${fmtTime(last.time)}", Color(0xFF1E5BFF))
                else SourceChip("No test run yet", Color.Gray)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Download", "${f1(last?.download)} Mbps", Modifier.weight(1f))
            StatCard("Upload", "${f1(last?.upload)} Mbps", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ping", "${f1(last?.pingMs)} ms", Modifier.weight(1f))
            StatCard("Jitter", "${f1(last?.jitterMs)} ms", Modifier.weight(1f))
        }
        Button(onClick = onRunTest, Modifier.fillMaxWidth()) { Text("Run speed test") }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SourceChip("Live", Good); SourceChip("Historical", Color(0xFF1E5BFF)); SourceChip("Reported", Average)
        }
        SourceChip("Estimated coverage (never shown as live speed)", Color.Gray)
    }
}

@Composable
fun MapScreen() {
    var selected by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Operators.forEach { op ->
                FilterChip(
                    selected = selected == op.name,
                    onClick = { selected = if (selected == op.name) null else op.name },
                    label = { Text(op.name) }
                )
            }
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Map, null, Modifier.size(56.dp))
                Text("Interactive map goes here (OpenStreetMap)", fontSize = 13.sp)
                Text("Filter: ${selected ?: "All operators"}", fontSize = 12.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            SourceChip("Good", Good); SourceChip("Average", Average); SourceChip("Poor", Poor)
        }
    }
}

@Composable
fun SpeedTestScreen(vm: NetViewModel) {
    Page {
        Speedometer(vm.liveSpeed, meterMax(vm.liveSpeed))
        if (vm.running || vm.liveSpeed != null) SourceChip("Live measured (Cloudflare servers)", Good)
        Text(vm.phase, fontSize = 14.sp)
        vm.error?.let { Text(it, color = Poor, fontSize = 13.sp) }
        Button(onClick = { vm.start() }, enabled = !vm.running) {
            Text(if (vm.running) "TESTING…" else "START TEST")
        }
        Text("${vm.net.operator}  •  ${vm.net.connection}", fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Download", f1(vm.download), Modifier.weight(1f))
            StatCard("Upload", f1(vm.upload), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ping (ms)", f1(vm.ping), Modifier.weight(1f))
            StatCard("Jitter (ms)", f1(vm.jitter), Modifier.weight(1f))
        }
        Text("Ping is HTTP round-trip time. Results use mobile data if you are on mobile data.", fontSize = 11.sp)
    }
}

@Composable
fun CompareScreen(vm: NetViewModel) {
    val stats = Operators.map { op ->
        val l = vm.history.filter { it.operator == op.name }
        op to l
    }
    val bestDown = stats.filter { it.second.isNotEmpty() }.maxOfOrNull { it.second.map { r -> r.download }.average() } ?: 0.0
    val withData = stats.filter { it.second.isNotEmpty() }
    Page {
        SourceChip("Historical: your own saved tests on this device", Color(0xFF1E5BFF))
        stats.forEach { (op, l) ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(op.color))
                        Spacer(Modifier.width(8.dp))
                        Text(op.name, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${l.size} tests", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (l.isEmpty()) Text("No tests yet", fontSize = 13.sp)
                    else {
                        val d = l.map { it.download }.average()
                        Text("Down ${f1(d)} | Up ${f1(l.map { it.upload }.average())} Mbps | Ping ${f1(l.map { it.pingMs }.average())} ms", fontSize = 13.sp)
                        LinearProgressIndicator(progress = { (d / bestDown).toFloat().coerceIn(0f, 1f) },
                            Modifier.fillMaxWidth().padding(top = 8.dp), color = op.color)
                    }
                }
            }
        }
        val best = withData.maxByOrNull { it.second.map { r -> r.download }.average() }
        Text(
            if (withData.size >= 2 && best != null) "Best download so far: ${best.first.name}"
            else "Run tests on at least 2 operators (switch SIMs) to compare.",
            fontSize = 13.sp
        )
    }
}

@Composable
fun HistoryScreen(vm: NetViewModel) {
    if (vm.history.isEmpty()) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.History, null, Modifier.size(56.dp))
            Text("No speed tests saved yet", fontWeight = FontWeight.SemiBold)
            Text("Your results will appear here.", fontSize = 13.sp)
        }
    } else Column(Modifier.fillMaxSize()) {
        TextButton(onClick = { vm.clearHistory() }, Modifier.align(Alignment.End)) { Text("Clear all") }
        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.history) { r ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${r.operator} • ${r.connection}", fontWeight = FontWeight.SemiBold)
                        Text(fmtTime(r.time), fontSize = 12.sp)
                        Text("Down ${f1(r.download)} | Up ${f1(r.upload)} Mbps | Ping ${f1(r.pingMs)} ms", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(dark: Boolean, onDark: (Boolean) -> Unit) {
    var share by remember { mutableStateOf(false) }
    Page {
        ListItem(
            headlineContent = { Text("Dark mode") },
            trailingContent = { Switch(checked = dark, onCheckedChange = onDark) }
        )
        ListItem(
            headlineContent = { Text("Share anonymous measurements") },
            supportingContent = { Text("Off by default. Location is only used with your permission.") },
            trailingContent = { Switch(checked = share, onCheckedChange = { share = it }) }
        )
        ListItem(headlineContent = { Text("NetTrack v0.1") }, supportingContent = { Text("Find Better Network. Experience Faster Internet.") })
    }
}

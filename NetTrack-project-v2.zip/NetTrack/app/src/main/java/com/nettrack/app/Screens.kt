package com.nettrack.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.io.File
import android.graphics.drawable.GradientDrawable
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

/** Speedometer. value == null means "no measurement" and shows "--" (never a fake number). */
@Composable
fun Speedometer(value: Float?, max: Float = 100f, modifier: Modifier = Modifier) {
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    val prim = MaterialTheme.colorScheme.primary
    val sweep = 240f * ((value ?: 0f) / max).coerceIn(0f, 1f)
    Box(modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val inset = 24f
            val sz = Size(size.width - 2 * inset, size.height - 2 * inset)
            val st = Stroke(width = 24f, cap = StrokeCap.Round)
            drawArc(track, 150f, 240f, false, Offset(inset, inset), sz, style = st)
            if (sweep > 0f) drawArc(prim, 150f, sweep, false, Offset(inset, inset), sz, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value?.let { "%.1f".format(it) } ?: "--", fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Text("Mbps", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun SourceChip(label: String, color: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 11.sp)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}

fun meterMax(v: Float?) = when { v == null || v <= 100f -> 100f; v <= 300f -> 300f; else -> 1000f }
fun fmtTime(t: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))
fun f1(v: Double?) = v?.let { "%.1f".format(it) } ?: "--"

@Composable
fun HomeScreen(vm: NetViewModel, onRunTest: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshNet() }
    LaunchedEffect(Unit) {
        vm.refreshNet()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.READ_PHONE_STATE)
    }
    val last = vm.history.firstOrNull()
    Page {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Current network (read from device)", fontSize = 12.sp)
                Text("${vm.net.operator}  •  ${vm.net.connection}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Speedometer(last?.download?.toFloat(), meterMax(last?.download?.toFloat()))
                if (last != null) SourceChip("Historical: last test ${fmtTime(last.time)}", Color(0xFF1E5BFF))
                else SourceChip("No test run yet", Color.Gray)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Download", "${f1(last?.download)} Mbps", Modifier.weight(1f))
            StatCard("Upload", "${f1(last?.upload)} Mbps", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ping", "${f1(last?.pingMs)} ms", Modifier.weight(1f))
            StatCard("Jitter", "${f1(last?.jitterMs)} ms", Modifier.weight(1f))
        }
        Button(onClick = onRunTest, Modifier.fillMaxWidth()) { Text("Run speed test") }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SourceChip("Live", Good); SourceChip("Historical", Color(0xFF1E5BFF)); SourceChip("Reported", Average)
        }
        SourceChip("Estimated coverage (never shown as live speed)", Color.Gray)
    }
}

private class Holder(var done: Boolean = false)

fun qualityColor(download: Double) = when { download >= 20.0 -> Good; download >= 5.0 -> Average; else -> Poor }

@Composable
fun MapScreen(vm: NetViewModel) {
    var selected by remember { mutableStateOf<String?>(null) }
    val points = vm.history.filter { it.lat != null && it.lon != null && (selected == null || it.operator == selected) }
    val centered = remember { Holder() }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Operators.forEach { op ->
                FilterChip(
                    selected = selected == op.name,
                    onClick = { selected = if (selected == op.name) null else op.name },
                    label = { Text(op.name) }
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    Configuration.getInstance().apply {
                        userAgentValue = ctx.packageName
                        osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
                        osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
                    }
                    MapView(ctx).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(5.0)
                        controller.setCenter(GeoPoint(22.5, 79.0))
                    }
                },
                update = { map ->
                    map.overlays.clear()
                    points.forEach { r ->
                        val m = Marker(map)
                        m.setPosition(GeoPoint(r.lat!!, r.lon!!))
                        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                        m.setIcon(GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(qualityColor(r.download).toArgb())
                            setSize(48, 48)
                            setStroke(4, android.graphics.Color.WHITE)
                        })
                        m.setTitle("${r.operator} • ${r.connection}")
                        m.setSnippet("Down ${f1(r.download)} | Up ${f1(r.upload)} Mbps | Ping ${f1(r.pingMs)} ms | ${fmtTime(r.time)}")
                        map.overlays.add(m)
                    }
                    if (!centered.done && points.isNotEmpty()) {
                        map.controller.setZoom(15.0)
                        map.controller.setCenter(GeoPoint(points[0].lat!!, points[0].lon!!))
                        centered.done = true
                    }
                    map.invalidate()
                }
            )
            if (points.isEmpty()) {
                Surface(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                ) {
                    Text("No located tests yet.\nRun a speed test with location allowed.", Modifier.padding(16.dp), fontSize = 13.sp)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SourceChip("Good 20+", Good); SourceChip("Average 5-20", Average); SourceChip("Poor <5", Poor)
        }
        Text("Historical: your own saved tests (download Mbps). ${points.size} on map.", fontSize = 11.sp)
    }
}

@Composable
fun SpeedTestScreen(vm: NetViewModel) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.start() }
    Page {
        Speedometer(vm.liveSpeed, meterMax(vm.liveSpeed))
        if (vm.running || vm.liveSpeed != null) SourceChip("Live measured (Cloudflare servers)", Good)
        Text(vm.phase, fontSize = 14.sp)
        vm.error?.let { Text(it, color = Poor, fontSize = 13.sp) }
        Button(onClick = {
            if (vm.saveLocation && !hasLocationPermission(ctx))
                permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            else vm.start()
        }, enabled = !vm.running) {
            Text(if (vm.running) "TESTING…" else "START TEST")
        }
        Text("${vm.net.operator}  •  ${vm.net.connection}", fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Download", f1(vm.download), Modifier.weight(1f))
            StatCard("Upload", f1(vm.upload), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ping (ms)", f1(vm.ping), Modifier.weight(1f))
            StatCard("Jitter (ms)", f1(vm.jitter), Modifier.weight(1f))
        }
        Text("Ping is HTTP round-trip time. Results use mobile data if you are on mobile data.", fontSize = 11.sp)
    }
}

@Composable
fun CompareScreen(vm: NetViewModel) {
    val stats = Operators.map { op ->
        val l = vm.history.filter { it.operator == op.name }
        op to l
    }
    val bestDown = stats.filter { it.second.isNotEmpty() }.maxOfOrNull { it.second.map { r -> r.download }.average() } ?: 0.0
    val withData = stats.filter { it.second.isNotEmpty() }
    Page {
        SourceChip("Historical: your own saved tests on this device", Color(0xFF1E5BFF))
        stats.forEach { (op, l) ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(op.color))
                        Spacer(Modifier.width(8.dp))
                        Text(op.name, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("${l.size} tests", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (l.isEmpty()) Text("No tests yet", fontSize = 13.sp)
                    else {
                        val d = l.map { it.download }.average()
                        Text("Down ${f1(d)} | Up ${f1(l.map { it.upload }.average())} Mbps | Ping ${f1(l.map { it.pingMs }.average())} ms", fontSize = 13.sp)
                        LinearProgressIndicator(progress = { (d / bestDown).toFloat().coerceIn(0f, 1f) },
                            Modifier.fillMaxWidth().padding(top = 8.dp), color = op.color)
                    }
                }
            }
        }
        val best = withData.maxByOrNull { it.second.map { r -> r.download }.average() }
        Text(
            if (withData.size >= 2 && best != null) "Best download so far: ${best.first.name}"
            else "Run tests on at least 2 operators (switch SIMs) to compare.",
            fontSize = 13.sp
        )
    }
}

@Composable
fun HistoryScreen(vm: NetViewModel) {
    if (vm.history.isEmpty()) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.History, null, Modifier.size(56.dp))
            Text("No speed tests saved yet", fontWeight = FontWeight.SemiBold)
            Text("Your results will appear here.", fontSize = 13.sp)
        }
    } else Column(Modifier.fillMaxSize()) {
        TextButton(onClick = { vm.clearHistory() }, Modifier.align(Alignment.End)) { Text("Clear all") }
        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.history) { r ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${r.operator} • ${r.connection}", fontWeight = FontWeight.SemiBold)
                        Text(fmtTime(r.time) + if (r.lat != null) "  •  location saved" else "", fontSize = 12.sp)
                        Text("Down ${f1(r.download)} | Up ${f1(r.upload)} Mbps | Ping ${f1(r.pingMs)} ms", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: NetViewModel, dark: Boolean, onDark: (Boolean) -> Unit) {
    Page {
        ListItem(
            headlineContent = { Text("Dark mode") },
            trailingContent = { Switch(checked = dark, onCheckedChange = onDark) }
        )
        ListItem(
            headlineContent = { Text("Save location with speed tests") },
            supportingContent = { Text("Used only to place your tests on the map. Stored on this phone. Turn off to stop saving location.") },
            trailingContent = { Switch(checked = vm.saveLocation, onCheckedChange = { vm.setSaveLoc(it) }) }
        )
        ListItem(headlineContent = { Text("NetTrack v0.3") }, supportingContent = { Text("Find Better Network. Experience Faster Internet.") })
    }
}
